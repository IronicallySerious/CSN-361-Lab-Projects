#include <stdio.h>
#include <unistd.h>

void main(void)
{
	int child1, child2;
	int i;
	child1 = fork();
	if (child1 == 0)
	{
		printf("This is a child1 process and pid is %d\n", getpid());

		int child11 = fork();
		if (child11 == 0)
		{
			printf("This is a child11 process and pid is %d\n", getpid());
		}
		else
		{
			int child12 = fork();
			if (child12 == 0)
			{
				printf("This is a child12 process and pid is %d\n", getpid());
			}
		}
	}
	else
	{
		child2 = fork();
		if (child2 == 0)
		{
			printf("This is a child2 process and pid is %d\n", getpid());

			int child21 = fork();
			if (child21 == 0)
			{
				printf("This is a child21 process and pid is %d\n", getpid());
			}
			else
			{
				int child22 = fork();
				if (child22 == 0)
				{
					printf("This is a child22 process and pid is %d\n", getpid());
				}
			}
		}
	}
}
