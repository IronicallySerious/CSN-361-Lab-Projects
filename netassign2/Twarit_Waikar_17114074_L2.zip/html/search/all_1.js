var searchData=
[
  ['port',['PORT',['../socket__connector_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;socket_connector.c'],['../socket__listener_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;socket_listener.c']]]
];
